<?php
//variable token de acceso
define('TOKEN_ACCS', 'INGRESE_TOKEN_AQUÍ');
?>
